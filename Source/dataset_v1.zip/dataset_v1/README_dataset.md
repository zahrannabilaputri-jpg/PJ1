# dataset_v1 (format YOLO)

- Sumber: frame penuh + label YOLO dari `sumber_frame/` pada repo
  AkbarL090/ret503-transfer-learning (anotasi Roboflow, kamera e-con See3CAM_CU135 di kepala robot, BRAIL, 24 Sep 2026).
  TODO penulis: pastikan sumber asli dan izin pemakaian data dicantumkan di README laporan.
- Split: diambil dari kolom `split` pada dataset_raw/metadata.csv (blok frame berurutan + frame jeda, anti-leakage).
  train 124 frame, val 23 frame, test 26 frame. 8 frame jeda (1654-1657, 1681-1684) tidak dipakai.
- Kelas: 0 backboard, 1 ball, 2 rim (kelas `latar` tidak dipakai; latar = area tanpa kotak).
- Koreksi label (3 kotak, semuanya di train), sesuai catatan salah label di README repo klasifikasi:
  frame 1533 kotak papan putih rim->backboard; frame 1550 dan 1552 kotak bola rim->ball.
- Jumlah kotak (backboard/ball/rim): train 110/117/115, val 20/15/21, test 25/26/25 (dihitung ulang setelah koreksi).
